<div id="ub-migrate-modal" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <!--<div class="modal-header">
                <button id="btn-modal-close" type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Confirmation</h4>
            </div>-->
            <div class="modal-body"></div>
            <div class="modal-footer">
                <button id="btn-modal-cancel" type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                <button id="btn-modal-ok" type="button" class="btn btn-default">Reset</button>
            </div>
        </div>
    </div>
</div>