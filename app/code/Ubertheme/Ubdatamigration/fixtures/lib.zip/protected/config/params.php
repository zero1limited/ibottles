<?php
return array(
    //limit number of records per each batch runtime
    'limit' => 100,
    //limit number of records per each batch runtime when resets the data migrated
    'reset_limit' => 100
);
